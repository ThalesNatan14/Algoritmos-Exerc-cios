#include<stdio.h>
#include <strings.h>

int main(){


    return 0;
}